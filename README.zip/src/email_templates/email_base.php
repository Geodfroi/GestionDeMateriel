<?php
################################
## Joël Piguet - 2021.12.13 ###
##############################
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <br><br>
    <?php echo $content ?>

    <footer>
        <br><br>
        <span style="vertical-align:top;font-size:14px">&emsp;HEdS - Service des innovations pédagogiques </span><br>
        <div style="font-size:14px">&emsp;Prière de ne pas répondre à cet email qui a été généré automatiquement.</div>
    </footer>
</body>

</html>