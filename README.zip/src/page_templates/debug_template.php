<?php
################################
## Joël Piguet - 2022.03.11 ###
##############################

?>

<div class="container">
</div>

<br><br>
<div>
    <textarea style="width: 100%; height : 40vh" name="" id="" cols="30" rows="10">
    #############################
    ##Joël Piguet - 2022.03.10##
    ###########################

    PHP v7.4.25 with Composer, coded with VSCode.

    functionality

    - Sqlite implementation on top of mysql for local testing (change in config.json).
    - Use own gmail address to send reminder emails.
    - Server backup to sqlite local db each day.
    - App was created to work on both desktop and smartphone. Use chrome or edge devKit to switch to phone view to see the result.
    </textarea>

    <div>TODO::</div>
    <br>
    <div>Bug with expiration date before filter in sqlite</div>
    <div>CONTACT: create contact page</div>
    <div>ADMIN - access user contact posts.</div>
    <div>ARTICLES: filter with created by</div>
    <div>LOGIN: replace with proper favicon</div>
</div>