<?php

################################
## Joël Piguet - 2022.01.13 ###
##############################

namespace app\routes;

use app\constants\Route;
use app\helpers\Authenticate;


/**
 * Route class containing behavior linked to profile_template. This route displays user info.
 */
class Profile extends BaseRoute
{
    function __construct()
    {
        parent::__construct(Route::PROFILE, 'profile_template', 'profile_script');
    }

    public function getBodyContent(): string
    {
        $user  = Authenticate::getUser();
        if (!$user) {
            return $this->requestRedirect(Route::HOME);
        }
        $contact_email = $user->getContactEmail();
        if ($contact_email === '') {
            $contact_email = $user->getLoginEmail();
        }

        return $this->renderTemplate(['login_email' => $user->getLoginEmail()]);
    }
}
