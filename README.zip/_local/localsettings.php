<?php

################################
## Joël Piguet - 2022.03.11 ###
##############################
// Private setting not to be stored in github. Fill-in and remove '_template suffix.

// database
const MYSQL_HOST = 'Orion';
const MYSQL_PORT = 3306;
const MYSQL_SCHEMA = 'heds_inv_exp'; # HEdS Inventory expiration
const MYSQL_ADMIN_ID = 'php_user';
const MYSQL_ADMIN_PASSWORD = 'kQMNM141jb2B';

// email account
const APP_EMAIL = 'innov.heds@gmail.com';
const APP_EMAIL_PASSWORD = 'cb88jJi92uUr';
